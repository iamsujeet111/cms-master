MAIN.id = 'db';
MAIN.db = {};